# rules.py

# List of common urgent or threatening keywords/phrases
URGENT_KEYWORDS = [
    "act now",
    "urgent",
    "account suspended",
    "verify your account",
    "immediate action required",
    "security alert",
    "compromised",
    "fraudulent activity",
    "payment failed",
    "invoice overdue",
    "click here",
    "update your information",
    "expiration notice",
    "unusual activity",
    "your attention is required"
]

# List of keywords indicating requests for sensitive information
SENSITIVE_INFO_KEYWORDS = [
    "password",
    "credit card number",
    "bank details",
    "social security number",
    "ssn",
    "pin",
    "login credentials",
    "date of birth",
    "security question answer",
    "cvv",
    "mfa code",
    "verification code",
    "authorize payment"
]

# Common suspicious attachment extensions
SUSPICIOUS_ATTACHMENT_EXTENSIONS = [
    ".exe", ".zip", ".js", ".vbs", ".scr", ".bat", ".cmd", ".ps1", ".hta",
    ".docm", ".xlsm", ".pptm", # Macro-enabled Office files
    ".lnk", # Shortcut files
    ".iso", ".img", # Disk images
    ".7z", ".rar", # Other archive formats
    ".wsf", ".cpl" # Windows Script File, Control Panel Item
]

# Common legitimate domains and patterns used by phishers to spoof them
# Key: legitimate domain
# Value: List of regex patterns for common spoofing attempts
COMMON_SPOOFED_DOMAINS = {
    "paypal.com": [
        r"paypal-security\.com$",
        r"paypal\.co\.uk\.login\.[\w\d-]+\.com$",
        r"paypai\.com$", # Typosquatting
        r"secure-paypal\.[\w\d-]+\.com$"
    ],
    "google.com": [
        r"google-security\.com$",
        r"accounts\.google\.co\.uk\.login\.[\w\d-]+\.com$",
        r"g0ogle\.com$"
    ],
    "microsoft.com": [
        r"microsoft-support\.com$",
        r"office365\.updates\.[\w\d-]+\.com$",
        r"micr0soft\.com$"  # <-- FIXED: Removed the extra 'r'
    ],
    "apple.com": [
        r"appleid\.security\.com$",
        r"icloud-login\.net$",
        r"apple\.co\.uk\.updates\.[\w\d-]+\.com$"
    ],
    "amazon.com": [
        r"amazon-security\.com$",
        r"amaz0n\.com$",
        r"amazon\.co\.uk\.order\.[\w\d-]+\.com$"
    ],
    "bankofamerica.com": [ # Example for a bank
        r"bofa-online\.com$",
        r"secure-bofa\.net$"
    ]
    # Add more as needed
}

# Patterns for suspicious URLs (beyond just spoofed domains)
SUSPICIOUS_URL_PATTERNS = {
    "shorteners": [ # Common URL shorteners
        "bit.ly", "tinyurl.com", "ow.ly", "goo.gl", "buff.ly", "rebrand.ly",
        "t.co", # Twitter's shortener, often legitimate but can be abused
        "cutt.ly", "rb.gy", "is.gd"
    ],
    "keywords_in_url": [ # Keywords often used in malicious URLs
        "login", "verify", "update", "secure", "account", "billing", "payment",
        "confirm", "alert", "error", "security", "portal", "client"
    ]
    # This list could be expanded with more patterns like excessive subdomains,
    # unusual character sets (punycode attacks), etc.
}