import re
from urllib.parse import urlparse
from textblob import TextBlob
import sys
import os
import argparse

# Import rules from a separate file
from rules import (
    URGENT_KEYWORDS, SENSITIVE_INFO_KEYWORDS, SUSPICIOUS_ATTACHMENT_EXTENSIONS,
    COMMON_SPOOFED_DOMAINS, SUSPICIOUS_URL_PATTERNS
)

class PhishingDetector:
    def __init__(self):
        self.email_content = ""
        self.classification = "Safe"
        self.triggered_criteria = []
        self.suggestions = []

    def load_email(self, content: str):
        self.email_content = content.lower() # Convert to lower for case-insensitive matching
        self.original_content = content # Keep original for highlighting
        self.classification = "Safe"
        self.triggered_criteria = []
        self.suggestions = []

    def _add_criteria(self, criterion: str, severity: str = "suspicious", suggestion: str = None):
        self.triggered_criteria.append((criterion, severity))
        if severity == "phishing" and self.classification != "🚨 Phishing": # Ensure phishing overrides others
            self.classification = "🚨 Phishing"
        elif severity == "suspicious" and self.classification == "Safe":
            self.classification = "⚠️ Suspicious"
        if suggestion and suggestion not in self.suggestions:
            self.suggestions.append(suggestion)

    def _extract_links(self):
        # Regex to find common URL patterns
        # This is a simplified regex; a more robust one might be needed for production
        urls = re.findall(r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+', self.email_content)
        # Also look for links in HTML format, e.g., <a href="...">
        html_urls = re.findall(r'<a\s+(?:[^>]*?\s+)?href=["\'](.*?)(?:["\']|\s+|>|$)', self.email_content)
        return list(set(urls + html_urls)) # Remove duplicates

    def _get_urls_and_texts(self):
        # Attempt to find <a href="URL">Link Text</a> patterns
        # This is for identifying mismatched link text and actual URLs
        # Use re.DOTALL to match across multiple lines if needed
        link_patterns = re.findall(r'<a\s+(?:[^>]*?\s+)?href=["\'](.*?)(?:["\']|\s+|>)(?:[^>]*)?>(.*?)<\/a>', self.original_content, re.IGNORECASE | re.DOTALL)
        # Convert to a list of (url, link_text) tuples
        return link_patterns

    def _check_urgent_language(self):
        for keyword in URGENT_KEYWORDS:
            if re.search(r'\b' + re.escape(keyword) + r'\b', self.email_content):
                self._add_criteria(f"Use of urgent/threatening language: '{keyword}'", "phishing",
                                   "Be wary of urgent demands; legitimate organizations usually don't pressure you.")

    def _check_sensitive_info_requests(self):
        for keyword in SENSITIVE_INFO_KEYWORDS:
            if re.search(r'\b' + re.escape(keyword) + r'\b', self.email_content):
                self._add_criteria(f"Request for sensitive information: '{keyword}'", "phishing",
                                   "Never share passwords, credit card numbers, or other sensitive personal information via email.")

    def _check_suspicious_links(self):
        # 1. Check for URL/text mismatch
        html_link_pairs = self._get_urls_and_texts()
        for url_in_tag, link_text in html_link_pairs:
            # Normalize link_text for comparison (remove whitespace, lower case)
            normalized_link_text = re.sub(r'\s+', '', link_text).lower()
            normalized_url = url_in_tag.replace('https://', '').replace('http://', '').lower()

            if url_in_tag and link_text:
                # Simple check: if the visible text is very different from the actual domain
                # This needs refinement for more robust checking
                try:
                    parsed_url = urlparse(url_in_tag)
                    domain_from_url = parsed_url.netloc
                    # Remove common prefixes for better comparison
                    domain_from_url_stripped = domain_from_url.replace('www.', '').split(':')[0] # Remove port if present

                    # Heuristic: if link text doesn't contain a significant part of the actual domain
                    # And if the link text is not just the URL itself
                    if domain_from_url_stripped and \
                       domain_from_url_stripped not in normalized_link_text and \
                       normalized_link_text != normalized_url and \
                       not url_in_tag.startswith("mailto:"): # Exclude mailto links
                        self._add_criteria(f"Suspicious link: Mismatched link text '{link_text}' and URL '{url_in_tag}'", "phishing",
                                           "Always hover over links to see the real URL before clicking. If it doesn't match the description or looks suspicious, don't click.")
                except Exception as e:
                    # Handle malformed URLs gracefully
                    # print(f"Warning: Could not parse URL '{url_in_tag}': {e}")
                    pass


        # 2. Check for general suspicious URL patterns
        all_found_urls = self._extract_links()
        for url in all_found_urls:
            try:
                parsed_url = urlparse(url)
                domain = parsed_url.netloc

                # Check for IP address in hostname
                if re.match(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$', domain):
                    self._add_criteria(f"Suspicious link: URL uses an IP address instead of a domain name: '{url}'", "phishing",
                                       "Legitimate websites rarely use raw IP addresses in their URLs.")
                    continue # Already flagged, move to next URL

                # Check for common URL shorteners (basic list)
                if any(pattern in domain for pattern in SUSPICIOUS_URL_PATTERNS["shorteners"]):
                    self._add_criteria(f"Suspicious link: Shortened URL detected: '{url}'", "suspicious",
                                       "Be cautious with shortened URLs, as they can hide the true destination.")
                    continue

                # Check for suspicious keywords in domain/path (e.g., "login", "verify" in non-standard places)
                for keyword in SUSPICIOUS_URL_PATTERNS["keywords_in_url"]:
                    if keyword in url:
                        self._add_criteria(f"Suspicious link: Keyword '{keyword}' found in URL: '{url}'", "suspicious",
                                           "Examine URLs carefully for unusual keywords or structures.")

            except ValueError: # Invalid URL
                self._add_criteria(f"Suspicious link: Malformed URL detected: '{url}'", "suspicious",
                                   "Malformed URLs can indicate an attempt to deceive.")
            except Exception as e:
                # print(f"Error processing URL {url}: {e}")
                pass

    def _check_spoofed_sender(self, sender_email: str = None):
        if not sender_email:
            # If no sender is provided, we can't perform this check robustly.
            # In a real .eml parser, you'd get this from headers.
            self._add_criteria("Cannot verify sender: Sender email not provided (requires .eml parsing)", "suspicious")
            self.suggestions.append("Always verify the sender's actual email address, not just the display name.")
            return

        sender_domain = sender_email.split('@')[-1].lower() # Ensure lowercased for comparison
        for legit_domain, spoof_patterns in COMMON_SPOOFED_DOMAINS.items():
            if sender_domain == legit_domain.lower(): # Check if it's the exact legitimate domain
                continue
            for pattern in spoof_patterns:
                # Use regex to match patterns like "paypal-security.com" for "paypal.com"
                if re.match(pattern, sender_domain):
                    self._add_criteria(f"Spoofed sender domain detected: '{sender_email}' resembles '{legit_domain}'", "phishing",
                                       "The sender's domain looks like a legitimate one but is slightly off. This is a common phishing tactic.")
                    return # Only flag once per sender

        # Basic check for suspicious-looking "from" addresses (e.g., random strings)
        # This regex is for general well-formedness, not exhaustive
        if not re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', sender_email):
             self._add_criteria(f"Suspicious sender email format: '{sender_email}'", "suspicious",
                               "Be cautious of email addresses with unusual characters or random-looking parts.")


    def _check_spelling_grammar_mistakes(self):
        blob = TextBlob(self.email_content)
        
        misspelled_count = 0
        misspelled_examples = []
        
        # Lowercasing the entire blob for consistent spell checking
        # TextBlob will tokenize and prepare words internally.
        
        for word_obj in blob.words:
            # Skip very short words (e.g., 'a', 'I') or numeric words
            # or words that are punctuation/symbols
            if len(word_obj) <= 2 or word_obj.isdigit() or not word_obj.isalpha():
                continue

            original_word_str = str(word_obj)
            corrected_word_str = str(word_obj.correct())

            # If the original word (as string) is different from its corrected version, it's a misspelling
            # We also try to avoid flagging proper nouns that TextBlob might correct to lowercase
            # Example: "Google" -> "google". We don't want to flag this as a misspelling.
            if original_word_str != corrected_word_str:
                # Heuristic: If original is capitalized and corrected is its lowercase version,
                # it might be a proper noun, so don't flag.
                if original_word_str.istitle() and original_word_str.lower() == corrected_word_str:
                    continue
                
                misspelled_count += 1
                if len(misspelled_examples) < 3: # Store up to 3 examples
                    misspelled_examples.append(original_word_str)

        if misspelled_count > 3: # Arbitrary threshold, adjust as needed
            example_str = ", ".join(misspelled_examples)
            self._add_criteria(f"Multiple spelling/grammar mistakes detected (e.g., '{example_str}')", "suspicious",
                               "Phishing emails often contain spelling and grammar errors.")

    def _check_unusual_attachments(self, attachments: list = None):
        if attachments:
            for attachment_name in attachments:
                _, ext = os.path.splitext(attachment_name)
                if ext.lower() in SUSPICIOUS_ATTACHMENT_EXTENSIONS:
                    self._add_criteria(f"Suspicious attachment extension detected: '{attachment_name}'", "phishing",
                                       "Never open attachments with suspicious extensions (.exe, .zip, .js, etc.) unless you are absolutely sure of their origin.")
        # Also check for common phrases indicating attachments, if no list is given
        # This check is less reliable without actual attachment data.
        if not attachments and any(phrase in self.email_content for phrase in ["attached file", "see attachment", "document is attached", "your bill is attached"]):
            self._add_criteria("Reference to an attachment without explicit attachment data (requires .eml parsing for verification)", "suspicious",
                               "If the email mentions an attachment but none is visible or if the sender is unknown, be very cautious.")


    def analyze(self, sender_email: str = None, attachments: list = None):
        self.classification = "Safe" # Reset for each analysis
        self.triggered_criteria = []
        self.suggestions = []

        self._check_urgent_language()
        self._check_sensitive_info_requests()
        self._check_suspicious_links()
        self._check_spoofed_sender(sender_email)
        self._check_spelling_grammar_mistakes()
        self._check_unusual_attachments(attachments)

        # Refine classification based on severity
        if any(sev == "phishing" for _, sev in self.triggered_criteria):
            self.classification = "🚨 Phishing"
            self.suggestions.insert(0, "**ACTION REQUIRED: This is highly likely a phishing email. DO NOT click any links, open attachments, or reply. Delete it immediately.**")
        elif self.triggered_criteria: # If any criteria triggered, but no 'phishing' ones
            self.classification = "⚠️ Suspicious"
            self.suggestions.insert(0, "**CAUTION: This email has suspicious elements. Proceed with extreme caution.**")
        else:
            self.classification = "✅ Safe"
            self.suggestions.append("This email appears safe, but always remain vigilant and verify sender authenticity.")

        # Ensure unique suggestions
        self.suggestions = list(set(self.suggestions))


    def get_results(self):
        results = {
            "classification": self.classification,
            "triggered_criteria": self.triggered_criteria,
            "suggestions": self.suggestions
        }
        return results

    def highlight_suspicious_phrases(self):
        highlighted_content = self.original_content

        # Highlight keywords for urgent language and sensitive info requests
        all_keywords_to_highlight = URGENT_KEYWORDS + SENSITIVE_INFO_KEYWORDS
        for keyword in all_keywords_to_highlight:
            # Use re.IGNORECASE for case-insensitivity and \b for whole word matching
            highlighted_content = re.sub(r'(?i)\b(' + re.escape(keyword) + r')\b', r'**\1**', highlighted_content)

        # Highlight suspicious links
        # This part is tricky as it modifies the string based on previous checks
        # Re-extract links from the original content to ensure highlighting works on original case/formatting
        all_found_urls_original_case = re.findall(r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+', self.original_content)
        
        for url in all_found_urls_original_case:
            try:
                parsed_url = urlparse(url)
                domain = parsed_url.netloc.lower() # Compare with lowercased domain

                is_flagged = False
                # Check if URL was flagged as suspicious based on domain/IP/shortener
                if re.match(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$', domain):
                    highlighted_content = highlighted_content.replace(url, f'**{url}** (IP Address URL)', 1)
                    is_flagged = True
                elif any(pattern in domain for pattern in SUSPICIOUS_URL_PATTERNS["shorteners"]):
                    highlighted_content = highlighted_content.replace(url, f'**{url}** (Shortened URL)', 1)
                    is_flagged = True
                else:
                    # Check for keywords in URL (path, query, etc.)
                    for keyword in SUSPICIOUS_URL_PATTERNS["keywords_in_url"]:
                        if keyword in url.lower() and not is_flagged: # Use lower() for comparison
                            highlighted_content = highlighted_content.replace(url, f'**{url}** (Suspicious Keyword in URL)', 1)
                            is_flagged = True
                            break # Flagged, move to next URL

                # If it's not already flagged by domain/IP/shortener, check for text mismatch
                if not is_flagged:
                    for url_in_tag, link_text in self._get_urls_and_texts():
                        if url_in_tag == url: # Check if this is the URL from the <a> tag
                            normalized_link_text = re.sub(r'\s+', '', link_text).lower()
                            normalized_url_tag = url_in_tag.replace('https://', '').replace('http://', '').lower()
                            domain_from_url_tag = urlparse(url_in_tag).netloc.replace('www.', '').split(':')[0].lower()

                            if domain_from_url_tag and \
                               domain_from_url_tag not in normalized_link_text and \
                               normalized_link_text != normalized_url_tag and \
                               not url_in_tag.startswith("mailto:"):
                                # This highlights the link text if it's a mismatch
                                # We need to be careful not to double-highlight if the raw URL also appears
                                # This is a basic approach and might need more robust HTML parsing for complex cases.
                                original_a_tag = f'<a href="{url_in_tag}">{link_text}</a>'
                                highlighted_a_tag = f'<a href="{url_in_tag}">**{link_text}** (URL: *{url_in_tag}*)</a>'
                                highlighted_content = highlighted_content.replace(original_a_tag, highlighted_a_tag, 1)
                                is_flagged = True # Mark as flagged
                                break # Move to the next URL
            except Exception:
                pass # Ignore errors during highlighting malformed URLs

        # Note: Spelling/grammar mistakes are harder to highlight cleanly without more advanced NLP or
        # token-level manipulation. The current output lists the examples.

        return highlighted_content

def main():
    parser = argparse.ArgumentParser(description="Phishing Email Detector Tool")
    parser.add_argument("-f", "--file", help="Path to an email text file (.txt).")
    parser.add_argument("-s", "--sender", help="Optional sender email address (e.g., 'support@paypal.com').")
    parser.add_argument("-a", "--attachments", nargs='*', help="Optional list of attachment filenames (e.g., 'invoice.exe report.pdf').")
    args = parser.parse_args()

    detector = PhishingDetector()

    email_content = ""
    if args.file:
        if not os.path.exists(args.file):
            print(f"Error: File not found at '{args.file}'")
            sys.exit(1)
        with open(args.file, 'r', encoding='utf-8', errors='ignore') as f:
            email_content = f.read()
        print(f"\n--- Analyzing email from file: {args.file} ---")
    else:
        print("--- Phishing Email Detector (Type/Paste Email Content, then press Ctrl+D or Ctrl+Z+Enter) ---")
        print("Enter email content:")
        # Read from stdin until EOF (Ctrl+D on Linux/macOS, Ctrl+Z then Enter on Windows)
        email_content = sys.stdin.read()
        print("\n--- Analyzing pasted email content ---")

    if not email_content.strip():
        print("No email content provided. Exiting.")
        return

    detector.load_email(email_content)
    detector.analyze(sender_email=args.sender, attachments=args.attachments)
    results = detector.get_results()

    print(f"\nClassification: {results['classification']}")
    print("\nExplanation:")
    if results['triggered_criteria']:
        for criterion, severity in results['triggered_criteria']:
            print(f"- [{severity.upper()}] {criterion}")
    else:
        print("- No specific suspicious criteria triggered.")

    print("\nSuggestions for User Safety:")
    for suggestion in results['suggestions']:
        print(f"- {suggestion}")

    print("\n--- Highlighted Suspicious Elements (Markdown formatted) ---")
    print(detector.highlight_suspicious_phrases())


if __name__ == "__main__":
    main()